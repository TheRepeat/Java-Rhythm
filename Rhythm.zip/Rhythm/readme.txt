Basic rhythm-based game in Java. Made in an afternoon to get comfortable with Java.
Press SPACE while the heart is lined up with the notes. Includes a normal and a hard difficulty. 

Modifies free-to-use code from this website: http://zetcode.com/tutorials/javagamestutorial/