package com.zetcode;

public class SpaceShip extends Sprite {

    public SpaceShip(int x, int y) {
        super(x, y);

        initCraft();
    }

    private void initCraft() {
        
        loadImage("resources/heart.png");
        getImageDimensions();
    }

}