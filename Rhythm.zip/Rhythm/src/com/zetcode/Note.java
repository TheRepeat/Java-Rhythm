package com.zetcode;

public class Note extends Sprite {

    private final int INITIAL_X = 400;
    public static int MOVE_SPD = 1;

    public Note(int x, int y) {
        super(x, y);

        initNote();
    }

    private void initNote() {

        loadImage("resources/note.png");
        getImageDimensions();
    }

    public void move() {

        if (x < 0) {
            x = INITIAL_X;
        }

        x -= MOVE_SPD;
    }
}