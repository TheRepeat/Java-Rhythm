package com.zetcode;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Board extends JPanel implements ActionListener {

    private Timer timer;
    private SpaceShip spaceship;
    private List<Note> Notes;
    private boolean ingame;
    private final int ICRAFT_X = 100;
    private final int ICRAFT_Y = 150;
    private final int B_WIDTH = 400;
    private final int B_HEIGHT = 300;
    private final int DELAY = 15;
    public int strikes = 0;
    public boolean valid = false; //player overlaps note, so hitting space doesn't raise the # of strikes
    public boolean keydown = false; //player is hitting space, so checkCollision can read it
    public boolean complete = false;
    
    private final int[][] pos = {
        {410, 150}, {450, 150}, {475, 150},
        {500, 150}, {540, 150}, {580, 150},
        {620, 150}, {645, 150}, {670, 150},
        {710, 150}, {750, 150}, {790, 150},
        {815, 150}, {840, 150}, {880, 150},
        {920, 150}, {980, 150}, {1060, 150},
        {1100, 150}, {1125, 150}, {1150, 150},
        {1190, 150}, {1230, 150}, {1270, 150},
        {1295, 150}, {1320, 150}, {1360, 150},
        {1400, 150}, {1440, 150}, {1465, 150},
        {1490, 150}, {1530, 150}, {1570, 150}, 
        {1640, 150} 
    };

    public Board() {

        initBoard();
    }

    private void initBoard() {

        addKeyListener(new TAdapter());
        setFocusable(true);
        setBackground(Color.BLACK);
        ingame = true;

        setPreferredSize(new Dimension(B_WIDTH, B_HEIGHT));

        spaceship = new SpaceShip(ICRAFT_X, ICRAFT_Y);

        initNotes();

        timer = new Timer(DELAY, this);
        timer.start();
    }

    public void initNotes() {
        
        Notes = new ArrayList<>();

        for (int[] p : pos) {
            Notes.add(new Note(p[0], p[1]));
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (ingame) {

            drawObjects(g);

        } else {

            drawGameOver(g);
        }

        Toolkit.getDefaultToolkit().sync();
    }

    private void drawObjects(Graphics g) {

        if (spaceship.isVisible()) {
            g.drawImage(spaceship.getImage(), spaceship.getX(), spaceship.getY(),
                    this);
        }

        for (Note Note : Notes) {
            if (Note.isVisible()) {
                g.drawImage(Note.getImage(), Note.getX(), Note.getY(), this);
            }
        }

        g.setColor(Color.WHITE);
        g.drawString("Notes left: " + Notes.size(), 5, 15);
        g.drawString("Strikes: " + strikes + "/3", 5, 30);
    }

    private void drawGameOver(Graphics g) {

    	String msg;
    	if(strikes == 3) {
            msg = "Game Over";
    	}
    	else {
    		msg = "Pass! (Press SPACE to restart on hard mode!)";
    		complete = true;
    	}
    	
        Font small = new Font("Helvetica", Font.BOLD, 14);
        FontMetrics fm = getFontMetrics(small);

        g.setColor(Color.white);
        g.setFont(small);
        g.drawString(msg, (B_WIDTH - fm.stringWidth(msg)) / 2,
                B_HEIGHT / 2);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        inGame();

        updateNotes();

        checkCollisions();

        repaint();
        
        loseCondition();
        
        keydown = false;
    }

    private void inGame() {

        if (!ingame) {
            timer.stop();
        }
    }

    private void updateNotes() {

        if (Notes.isEmpty()) {

            ingame = false;
            return;
        }

        for (int i = 0; i < Notes.size(); i++) {

            Note a = Notes.get(i);
            
            if (a.isVisible()) {
                a.move();
            } else {
                Notes.remove(i);
            }
        }
    }

    public void checkCollisions() {

        Rectangle r3 = spaceship.getBounds();

        for (Note Note : Notes) {
            
            Rectangle r2 = Note.getBounds();

            if (r3.intersects(r2)) {
                valid = true;
                /*spaceship.setVisible(false);
                Note.setVisible(false);
                ingame = false;*/
                if(keydown) {
                	Note.setVisible(false);
                	
                }
            }
            else {
            	valid = false;
            }
            if(Note.x < 1) { //missed note
                Note.setVisible(false);
                strikes++;
            }
        }
    }
    
    public void loseCondition() {
    	for (Note Note : Notes) {
    		if (strikes == 3) {
        		spaceship.setVisible(false);
        		Note.setVisible(false);
                ingame = false;
        	}
    	}
    }


    private class TAdapter extends KeyAdapter {
    	
        @Override
        public void keyPressed(KeyEvent e) {
        	int key = e.getKeyCode();
           	if (key == KeyEvent.VK_SPACE) {
               	if(complete) {
               		strikes = 0;
               		Note.MOVE_SPD = 2;
               		initBoard();
               		complete = false;
               	}
            }
        }
        
        @Override
        public void keyReleased(KeyEvent e) {
        	int key = e.getKeyCode();
           	if (key == KeyEvent.VK_SPACE) {
               	keydown = true;
            }
        }
        
    }    
}